#include <Servo.h>

#include <Wire.h>
#include <CameraC328R.h>
#include <DS1307.h>
#include <NMEA.h>

//Variables
#include "WProgram.h"
void setup();
void rev();
void loop();
int datetime[7];
CameraC328R camera;
NMEA gps;
Servo motor;
float volts, watts, amps, mph, rpm;
unsigned int throttle;
volatile unsigned long lasttime, nowtime;

static uint16_t pictureSizeCount = 0;

/**
 * This callback is called EVERY time a JPEG data packet is received.
 *
 * void getJPEGPicture_callback( uint16_t pictureSize, uint16_t packageSize, uint16_t packageCount, byte* package )
 * {
 * // packageSize is the size of the picture part of the package
 * pictureSizeCount += packageSize;
 * 
 * for( uint16_t i = 0; i < packageSize; i++ )
 * {
 * Serial.print( package[i], BYTE );
 * }
 * 
 * if( pictureSizeCount == pictureSize )
 * {
 * camera.powerOff();
 * }
 * }
 */
void setup()
{
  Wire.begin();  

  //Camera Serial Line
  //Serial.begin(57600);

  //Bluetooth Serial Line
  Serial1.begin(115200);

  //Screen Serial Line
  Serial2.begin(115200);

  //GPS Serial Line
  Serial3.begin(38200);

  //Motor Initialise
  motor.attach(9);
  motor.writeMicroseconds(1000);


  //Begin counting revolutions

  rpm = 0;
  nowtime = millis();
  lasttime = millis();
  attachInterrupt(0, rev, RISING);
}

void rev()
{  
  lasttime = nowtime;
  nowtime = millis();
}

void loop()
{
  Serial2.print('\r');

  Serial2.print("RTC Date: ");
  Serial2.print(datetime[2],DEC);
  Serial2.print(":");
  Serial2.print(datetime[1],DEC);
  Serial2.print(":");
  Serial2.print(datetime[0],DEC);
  Serial2.print(" ");
  Serial2.print(datetime[5],DEC);
  Serial2.print("-");
  Serial2.print(datetime[4],DEC);
  Serial2.print("-");
  Serial2.print(datetime[6],DEC);
  Serial2.print(" PST\n");
  delay(50);

  Serial2.print(" Voltage: ");
  //( (5V) / (1204 steps) * read steps ) / 63.69mV 
  volts = (float)analogRead(3)*0.0766653;
  Serial2.print(volts);
  Serial2.print(" V\n");
  delay(50);

  Serial2.print(" Current: ");
  //( (5V) / (1204 steps) * read steps ) / 36.60mV 
  amps = (float)analogRead(2)*0.13341;
  Serial2.print(amps);
  Serial2.print(" A\n");
  delay(50);

  Serial2.print("   Power: ");
  watts = volts * amps;
  Serial2.print(watts);
  Serial2.print(" W\n");
  delay(50);

  throttle = analogRead(0);
  
  if( throttle < 100 )
  { 
    motor.writeMicroseconds(1000);
    //throttle = 0;   
  }
  else if( throttle > 600 )  
  {    
    motor.writeMicroseconds(2000);
    //throttle = 100;    
  }
  else
  {  
    motor.writeMicroseconds(map(throttle,100,600,1000,2000));    
    //throttle = map(throttle,100,600,0,100);  
  }
  
  Serial2.print("Throttle: ");
  Serial2.print(throttle);
  Serial2.print(" %\n");
  delay(50);

  /*if(revolutions > 10)
  {    
    rpm = (float)( (float)revolutions / (float)(millis() - lasttime) ) * 60000;
    revolutions = 0;
    lasttime = millis();
  }*/
  
  rpm = (float)1/(float)(millis() - lasttime ) * 60000;
  Serial2.print("    Revs: ");
  Serial2.print(rpm);
  Serial2.print(" rpm\n");
  delay(50);


  //       X rev   60 min   62 in    1 mile    miles
  // mph = ----- * ------ * ----- * -------- = -----
  //       1 min   1 hour   1 rev   63360 in   hour
  
  mph = 0.058712 * rpm;
  Serial2.print("WheelMPH: ");
  Serial2.print(mph);
  Serial2.print(" mph\n");
  delay(50);

  for( int i = Serial3.available() ; i > 0 ; --i )
  {
    if( gps.Parse(Serial3.read()) )
    {      
      i = -1;
      Serial2.print("\nGPS Date: ");
      Serial2.print(gps.utc.hour,DEC);
      Serial2.print(":");
      Serial2.print(gps.utc.min,DEC);
      Serial2.print(":");
      Serial2.print(gps.utc.sec,DEC);
      Serial2.print(" ");
      Serial2.print(gps.utc.month,DEC);
      Serial2.print("-");
      Serial2.print(gps.utc.day,DEC);
      Serial2.print("-20");
      Serial2.print(gps.utc.year,DEC);
      Serial2.print(" UTC\n");

      delay(50);

      Serial2.print("Location: ");
      Serial2.printFloat(gps.latitude,8);
      Serial2.print(", ");
      Serial2.printFloat(gps.longitude,8);
      Serial2.print("\n");

      delay(50);

      Serial2.print("   Speed: ");
      Serial2.print(gps.speed);
      Serial2.print("mph\n");

      delay(50);

      Serial2.print(" Heading: ");
      Serial2.print(gps.direction);
      Serial2.print("deg ");
      Serial2.print(gps.declination);
      Serial2.print("dec");
    }
  }

  RTC.get(datetime, 1);
  /*
  if(Serial1.available())
   {
   switch(Serial1.read())
   {
   case '1':
   motor.writeMicroseconds(1000);
   break;
   case '2':
   motor.writeMicroseconds(1200);
   break;
   case '3':
   motor.writeMicroseconds(1300);
   break;
   case '4':
   motor.writeMicroseconds(1400);
   break;
   case '5':
   motor.writeMicroseconds(1500);
   break;
   case '6':
   motor.writeMicroseconds(1600);
   break;
   case '7':
   motor.writeMicroseconds(1700);
   break;
   case '8':
   motor.writeMicroseconds(1800);
   break;
   case '9':
   motor.writeMicroseconds(1900);
   break;
   case '0':
   motor.writeMicroseconds(2000);
   break;
   
   case 'P':
   Serial1.println("Photo");
   
   if( camera.sync() )
   if( camera.initial( CameraC328R::CT_JPEG, CameraC328R::PR_160x120, CameraC328R::JR_640x480 ) )
   if( camera.setPackageSize( 64 ) )
   if( camera.setLightFrequency( CameraC328R::FT_50Hz ) )
   {
   delay(2000);
   if( camera.snapshot( CameraC328R::ST_COMPRESSED, 0 ) )
   {
   Serial1.println( "snapshot failed" );
   }
   if( !camera.getJPEGPicture( CameraC328R::PT_JPEG, PROCESS_DELAY, &getJPEGPicture_callback ) )
   {
   Serial1.println( "Get JPEG failed." );
   }
   }
   break;
   default:
   Serial1.println("Unknown Command");
   break;
   }
   Serial1.println("Done");
   
   }*/
}

int main(void)
{
	init();

	setup();
    
	for (;;)
		loop();
        
	return 0;
}

